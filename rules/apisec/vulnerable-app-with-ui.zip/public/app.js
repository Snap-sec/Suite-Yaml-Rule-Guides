const app = {
    state: {
        token: null,
        user: null
    },

    // --- Navigation ---
    showView: (viewId) => {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        const targetView = document.getElementById(`view-${viewId}`);
        if(targetView) targetView.classList.add('active');
        
        document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
        const navLink = document.getElementById(`nav-${viewId}`);
        if(navLink) navLink.classList.add('active');
    },

    updateNav: () => {
        if (app.state.token) {
            document.body.classList.remove('login-mode');
            document.getElementById('app-container').style.display = 'flex';
            document.getElementById('view-login').style.display = 'none';
        } else {
            document.body.classList.add('login-mode');
            document.getElementById('app-container').style.display = 'none';
            document.getElementById('view-login').style.display = 'flex';
        }
    },

    showAlert: (elementId, message, type = 'success') => {
        const el = document.getElementById(elementId);
        el.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
        setTimeout(() => el.innerHTML = '', 5000);
    },

    // --- API Interactions ---

    handleLogin: async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const redirectUrl = document.getElementById('redirect_to').value;

        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, redirect_to: redirectUrl })
            });
            
            if (res.redirected) {
                window.location.href = res.url;
                return;
            }
            
            const data = await res.json();
            if (data.token) {
                app.state.token = data.token;
                app.updateNav();
                app.showView('dashboard');
                app.fetchTransactions();
            } else {
                app.showAlert('login-alert', 'Login failed', 'error');
            }
        } catch (err) {
            app.showAlert('login-alert', 'Login failed', 'error');
        }
    },

    logout: () => {
        app.state.token = null;
        app.updateNav();
        app.showView('login');
    },

    handleSearch: (e) => {
        e.preventDefault();
        const q = document.getElementById('searchInput').value;
        // Trigger Reflected XSS endpoint directly via navigation so it runs in browser
        window.location.href = `/api/search?q=${encodeURIComponent(q)}`;
    },

    fetchTransactions: async () => {
        const id = document.getElementById('txIdInput').value;
        const tbody = document.getElementById('txTableBody');
        const errDiv = document.getElementById('txError');
        
        tbody.innerHTML = '<tr><td colspan="3">Loading...</td></tr>';
        errDiv.innerText = '';

        try {
            const res = await fetch(`/api/transactions?id=${id}`);
            const data = await res.json();
            
            if (res.ok) {
                tbody.innerHTML = data.data.map(tx => `
                    <tr>
                        <td>${tx.id}</td>
                        <td>$${tx.amount}</td>
                        <td>${tx.description}</td>
                    </tr>
                `).join('');
            } else {
                tbody.innerHTML = '<tr><td colspan="3">Error loading transactions</td></tr>';
                errDiv.innerText = data.error || 'Unknown error'; // SQLi error leaked here
            }
        } catch (err) {
            errDiv.innerText = err.message;
        }
    },

    handleProfileUpdate: async (e) => {
        e.preventDefault();
        const email = document.getElementById('profileEmail').value;
        
        // Simulating the mass assignment vulnerability. The tool will inject payload here.
        // We only send email natively, but the tool will intercept and add role:admin
        try {
            const res = await fetch('/api/profile', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            const data = await res.json();
            
            if (data.profile) {
                document.getElementById('profileRole').value = data.profile.role;
                app.showAlert('profile-alert', `Profile updated. Role is now: ${data.profile.role}`, 'success');
            }
        } catch (err) {
            app.showAlert('profile-alert', 'Update failed', 'error');
        }
    },

    fetchReceipt: async () => {
        const url = document.getElementById('receiptUrl').value;
        const out = document.getElementById('receiptOutput');
        out.style.display = 'block';
        out.innerText = 'Fetching...';

        try {
            const res = await fetch('/api/fetch-receipt', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url })
            });
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    handlePing: async () => {
        const ip = document.getElementById('pingIp').value;
        const out = document.getElementById('pingOutput');
        out.innerText = 'Pinging...';

        try {
            const res = await fetch(`/api/system/ping?ip=${encodeURIComponent(ip)}`);
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    handleXmlImport: async () => {
        const xml = document.getElementById('xmlInput').value;
        const out = document.getElementById('xmlOutput');
        out.style.display = 'block';
        out.innerText = 'Uploading...';

        try {
            const res = await fetch('/api/transactions/import', {
                method: 'POST',
                headers: { 'Content-Type': 'text/xml' },
                body: xml
            });
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    testAdminAccess: async () => {
        const token = document.getElementById('jwtInput').value;
        const out = document.getElementById('adminOutput');
        out.style.display = 'block';
        out.innerText = 'Testing...';

        try {
            const res = await fetch('/api/admin/users', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            out.innerText = JSON.stringify(data, null, 2);
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    searchTransactions: async () => {
        const mode = document.getElementById('txSearchMode').value;
        const input = document.getElementById('txSearchInput').value;
        const out = document.getElementById('txSearchOutput');
        out.style.display = 'block';
        out.innerText = 'Searching...';

        try {
            let bodyData = {};
            try { bodyData = JSON.parse(input); } catch(e) { bodyData = { query: input }; }
            
            // If secure, we hit a secure endpoint (doesn't exist but simulates safe behavior)
            // We use the vulnerable one to trigger NoSQLi
            const url = mode === 'secure' ? '/api/v2/transactions' : '/api/transactions/search';
            
            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyData)
            });
            const data = await res.json();
            out.innerText = JSON.stringify(data, null, 2);
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    exportData: async () => {
        const out = document.getElementById('exportOutput');
        out.style.display = 'block';
        out.innerText = 'Exporting...';
        try {
            const res = await fetch('/api/transactions/export');
            const data = await res.json();
            out.innerText = JSON.stringify(data, null, 2);
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    downloadDocument: async () => {
        const mode = document.getElementById('docMode').value;
        const file = document.getElementById('docFile').value;
        const out = document.getElementById('docOutput');
        out.style.display = 'block';
        out.innerText = 'Downloading...';

        const url = mode === 'secure' ? '/api/v2/documents' : `/api/documents/download?file=${encodeURIComponent(file)}`;
        try {
            const res = await fetch(url);
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    runScript: async () => {
        const script = document.getElementById('scriptInput').value;
        const out = document.getElementById('scriptOutput');
        out.style.display = 'block';
        out.innerText = 'Executing...';

        try {
            const res = await fetch('/api/diagnostics/run-script', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ script })
            });
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    renderTemplate: async () => {
        const msg = document.getElementById('templateInput').value;
        const out = document.getElementById('templateOutput');
        out.style.display = 'block';
        out.innerText = 'Rendering...';

        try {
            const res = await fetch(`/api/template/render?msg=${encodeURIComponent(msg)}`);
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    },

    fetchLogs: async () => {
        const out = document.getElementById('logsOutput');
        out.style.display = 'block';
        out.innerText = 'Fetching logs...';

        try {
            const res = await fetch('/api/system/logs');
            const text = await res.text();
            out.innerText = text;
        } catch (err) {
            out.innerText = `Error: ${err.message}`;
        }
    }
};

// Initialize
app.updateNav();
